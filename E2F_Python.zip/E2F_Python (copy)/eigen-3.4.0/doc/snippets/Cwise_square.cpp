Array3d v(2,3,4);
cout << v.square() << endl;
