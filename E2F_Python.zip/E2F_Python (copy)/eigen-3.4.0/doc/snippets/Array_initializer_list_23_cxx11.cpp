ArrayXXi a {
  {1, 2, 3},
  {3, 4, 5}
};
cout << a << endl;
