Array4d v(-1,0,1,2);
cout << log10(v) << endl;
